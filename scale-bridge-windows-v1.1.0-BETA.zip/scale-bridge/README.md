# Scale Bridge - Local Synchronization Service

## What is Scale Bridge?

Scale Bridge is a lightweight service that runs locally at each branch to enable communication between the cloud-based backend and local scales.

### Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│ Cloud Backend (https://api.grettas-erp.com)                      │
│           ↕ WebSocket (HTTPS - secure outbound connection)       │
└──────────────────────────────────────────────────────────────────┘
                              ↕
┌──────────────────────────────────────────────────────────────────┐
│ Scale Bridge (runs at branch)                                     │
│           ↕ FTP/HTTP/TCP/RS-232 Serial                           │
└──────────────────────────────────────────────────────────────────┘
                              ↕
┌──────────────────────────────────────────────────────────────────┐
│ Kretz Scale (Network: 192.168.x.x OR Serial: COM1/COM2/etc.)    │
└──────────────────────────────────────────────────────────────────┘
```

**Benefits:**
- ✅ No VPN required
- ✅ No port forwarding required
- ✅ No firewall configuration changes
- ✅ Secure HTTPS WebSocket connection
- ✅ Automatic reconnection on network issues
- ✅ Runs as Windows service (auto-starts on boot)
- ⚠️ RS-232 support implemented but NOT tested with real hardware

---

## ⚠️ IMPORTANT WARNING

**RS-232/Serial support is BETA and UNTESTED with real Kretz hardware.**

The serial implementation is based on standard RS-232 communication patterns but has NOT been verified with actual Kretz Report or Kretz Single scales.

**May require adjustments for:**
- CSV format specific to Kretz models
- Line terminators (\r\n vs \r vs \n)
- Timing delays between lines
- Handshaking or initialization commands
- Response handling from scale

**Test thoroughly before production use.**

---

## Version History

### v1.1.0-BETA (2026-01-30)
- Added RS-232/Serial protocol support for COM port scales
- ⚠️ NOT tested with real Kretz hardware - requires validation
- May need protocol adjustments after hardware testing

### v1.0.0 (2026-01-29)
- Initial release
- FTP, HTTP, and TCP protocol support
- Windows service installation
- Automatic reconnection
- Logging system

---

## Protocol Support

| Protocol | Status | Use Case |
|----------|--------|----------|
| FTP | ✅ Production Ready | Network scales with FTP server |
| HTTP | ✅ Production Ready | Network scales with HTTP API |
| TCP | ✅ Production Ready | Network scales with raw socket |
| **RS-232 Serial** | ⚠️ **BETA - UNTESTED** | COM port scales (Kretz Report/Single) |

---

## Installation Instructions

See **README_CLIENTE.txt** for detailed Spanish instructions for RS-232 setup.

### Prerequisites

- **Node.js 18.x or higher** installed on Windows PC at branch
- **Administrator privileges** to install Windows service
- **For RS-232**: Python 3.x + Visual Studio Build Tools (required to compile serialport module)

### Quick Start

```bash
cd C:\scale-bridge
npm install  # ⚠️ For RS-232: Requires Python + VS Build Tools
node index.js
```

---

## Configuration

Configure scale connection in the web interface:
- **Configuración** → **Balanza**
- Select protocol: **RS-232/Serial**, FTP, HTTP, or TCP
- For Serial: Select COM port (COM1, COM2, etc.) and baud rate (9600)
- For Network: Enter IP address and port

---

## Troubleshooting

### npm install fails (RS-232 only)

**Error**: `gyp ERR! ...`

**Solution**: Install requirements for native module compilation:
1. Python 3.x: https://www.python.org/downloads/
2. Visual Studio Build Tools: https://visualstudio.microsoft.com/downloads/
3. Restart CMD and run `npm install` again

### Serial port open failed

- Verify COM port number in Device Manager
- Close other programs using the COM port
- Check if USB-Serial adapter drivers are installed

### Scale doesn't respond (RS-232)

⚠️ **Possible causes (UNTESTED protocol)**:
- Incorrect CSV format for your Kretz model
- Wrong line terminators
- Timing too fast/slow
- Missing initialization commands

**Action**: Check logs/combined.log and report findings

---

## Logs

Location: `C:\scale-bridge\logs\`
- `combined.log`: All events
- `error.log`: Only errors

Always check logs when troubleshooting issues.

---

## For Developers

### Testing Without Backend

```javascript
const ScaleClient = require('./scaleClient');
const client = new ScaleClient();

// Test Serial (RS-232)
client.testConnection({
  ip: 'COM1',        // COM port name
  port: 9600,        // Baud rate
  protocol: 'serial',
}).then(result => {
  console.log('Serial test:', result);
}).catch(error => {
  console.error('Serial test failed:', error);
});
```

---

## Support

For issues:
1. Check `logs/combined.log` for errors
2. Verify configuration in web interface
3. For RS-232 issues: Report logs + Kretz model info

---

## Known Limitations

- RS-232 implementation NOT verified with real Kretz hardware
- CSV format may need adjustments for specific Kretz models
- Line-by-line transmission timing may need tuning
- npm install requires Python + VS Build Tools (Windows only issue)

USE RS-232 FEATURE AT YOUR OWN RISK. Report all findings.
