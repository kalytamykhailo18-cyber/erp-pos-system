# Scale Bridge - Deployment Guide for Branches

This guide explains how to deploy the Scale Bridge service to each branch location.

---

## Prerequisites

Each branch PC must have:
- Windows 10/11 (64-bit recommended)
- Node.js 18+ installed
- Network access to the scale (same local network)
- Internet access to reach `https://api.grettas-erp.com`
- Administrator access for installing Windows service

---

## Branch Information

### Branch IDs (CRITICAL - DO NOT MIX THESE UP!)

| Branch Name | Branch ID | Status |
|-------------|-----------|--------|
| Sucursal Central (BR004) | `a72df959-f80d-4b4a-bad7-a148179c1259` | ✅ INSTALLED |
| Sucursal La Tablada (BR001) | `edbecacf-0625-4898-b3da-257f6b9dfddf` | ⏳ PENDING |
| Sucursal San Justo (BR002) | `4255ce7d-ab28-4488-a69f-91135a82a082` | ⏳ PENDING |
| Sucursal Villa del Parque (BR003) | `459a1c17-2dcf-4df4-95fc-a9e0b15d3bac` | ⏳ PENDING |

---

## Step-by-Step Installation

### Step 1: Copy Files to Branch PC

Copy the entire `/home/erp-pos-system/scale-bridge/` folder to the branch PC.

**Recommended location**: `C:\ScaleBridge\`

The folder should contain:
```
C:\ScaleBridge\
├── index.js
├── scaleClient.js
├── logger.js
├── package.json
├── .env.example
├── install-service.js
├── uninstall-service.js
├── INSTALL.bat
├── README.md
├── BRANCH_IDS.txt
└── node_modules\ (will be created)
```

### Step 2: Install Node.js (if not already installed)

1. Download Node.js 18 LTS from: https://nodejs.org/
2. Run the installer
3. Verify installation:
   ```cmd
   node --version
   npm --version
   ```

### Step 3: Install Dependencies

Open Command Prompt **as Administrator**:

```cmd
cd C:\ScaleBridge
npm install
```

Expected output:
```
added 150 packages in 12s
```

### Step 4: Configure Branch ID

Create a `.env` file with the correct Branch ID:

```cmd
cd C:\ScaleBridge
copy .env.example .env
notepad .env
```

Edit the `.env` file:

**For Sucursal La Tablada (BR001)**:
```env
BRANCH_ID=edbecacf-0625-4898-b3da-257f6b9dfddf
BACKEND_URL=https://api.grettas-erp.com
LOG_LEVEL=info
```

**For Sucursal San Justo (BR002)**:
```env
BRANCH_ID=4255ce7d-ab28-4488-a69f-91135a82a082
BACKEND_URL=https://api.grettas-erp.com
LOG_LEVEL=info
```

**For Sucursal Villa del Parque (BR003)**:
```env
BRANCH_ID=459a1c17-2dcf-4df4-95fc-a9e0b15d3bac
BACKEND_URL=https://api.grettas-erp.com
LOG_LEVEL=info
```

⚠️ **CRITICAL**: Make sure you use the correct Branch ID for each location!

### Step 5: Test the Service

Before installing as a Windows service, test it manually:

```cmd
cd C:\ScaleBridge
node index.js
```

Expected output:
```
2026-01-29 16:04:53 [info]: === Scale Bridge Service Starting ===
2026-01-29 16:04:53 [info]: Branch ID: edbecacf-0625-4898-b3da-257f6b9dfddf
2026-01-29 16:04:53 [info]: Backend URL: https://api.grettas-erp.com
2026-01-29 16:04:53 [info]: Connecting to backend...
2026-01-29 16:04:53 [info]: Target: https://api.grettas-erp.com/scale-bridge
2026-01-29 16:04:53 [info]: ✅ Connected to backend successfully
2026-01-29 16:04:53 [info]: Socket ID: xyz123abc456
```

If you see "✅ Connected to backend successfully", the service is working!

Press `Ctrl+C` to stop the test.

### Step 6: Install as Windows Service

Run the installer script:

```cmd
cd C:\ScaleBridge
node install-service.js
```

Expected output:
```
Installing Scale Bridge Service...
Service installed successfully!
Starting service...
Service started successfully!

Service Name: ScaleBridge
Display Name: Grettas Scale Bridge Service
Status: Running

To uninstall: node uninstall-service.js
```

Or use the batch file:
```cmd
cd C:\ScaleBridge
INSTALL.bat
```

### Step 7: Verify Service is Running

Check Windows Services:
1. Press `Win+R`
2. Type `services.msc` and press Enter
3. Look for "Grettas Scale Bridge Service"
4. Status should be "Running"
5. Startup Type should be "Automatic"

Or use Command Prompt:
```cmd
sc query ScaleBridge
```

### Step 8: Check Logs

Logs are stored in `C:\ScaleBridge\logs\`:

```cmd
cd C:\ScaleBridge\logs
type combined.log
```

You should see connection success messages.

### Step 9: Verify on Backend

From any PC with internet access, verify the branch is connected:

1. Login to https://grettas-erp.com
2. Open browser console (F12)
3. Run this code (replace with actual token after login):

```javascript
fetch('https://api.grettas-erp.com/api/v1/system/scale-bridges', {
  headers: {
    'Authorization': 'Bearer YOUR_JWT_TOKEN_HERE'
  }
})
.then(r => r.json())
.then(data => console.log(data));
```

You should see your branch ID in the list of connected bridges.

---

## Troubleshooting

### Problem: "Cannot find module"

**Solution**: Run `npm install` again:
```cmd
cd C:\ScaleBridge
npm install
```

### Problem: "BRANCH_ID not configured!"

**Solution**: Make sure you created the `.env` file with the correct Branch ID:
```cmd
cd C:\ScaleBridge
notepad .env
```

### Problem: "Connection error: websocket error"

**Solutions**:
1. Check internet connection
2. Verify backend URL is correct in `.env`
3. Check Windows Firewall is not blocking Node.js
4. Try disabling antivirus temporarily

### Problem: Service won't start

**Solution**: Check if port is already in use or try running manually first:
```cmd
cd C:\ScaleBridge
node index.js
```

### Problem: Service installed but not connecting

**Solution**: Check the logs:
```cmd
cd C:\ScaleBridge\logs
type error.log
```

---

## Uninstalling

To uninstall the service:

```cmd
cd C:\ScaleBridge
node uninstall-service.js
```

Or:
```cmd
sc stop ScaleBridge
sc delete ScaleBridge
```

---

## Firewall Configuration

If Windows Firewall blocks the connection:

1. Open Windows Defender Firewall
2. Click "Allow an app through firewall"
3. Find "Node.js" or "node.exe"
4. Check both "Private" and "Public"
5. Click OK

Or create a rule manually:
```cmd
netsh advfirewall firewall add rule name="Scale Bridge" dir=out action=allow program="C:\Program Files\nodejs\node.exe" enable=yes
```

---

## Testing Scale Connection

After the Scale Bridge is installed and connected:

1. Login to https://grettas-erp.com
2. Go to Configuration → Scale Settings
3. Configure your scale IP and connection details
4. Click "Test Connection"

If the Scale Bridge is working, you should be able to:
- Test scale connectivity
- Upload price lists
- Read weight from scale

---

## Monitoring

### Check Service Status

```cmd
sc query ScaleBridge
```

### View Real-Time Logs

```cmd
cd C:\ScaleBridge\logs
powershell Get-Content combined.log -Wait
```

### Restart Service

```cmd
sc stop ScaleBridge
sc start ScaleBridge
```

---

## Support

For issues:

1. Check logs in `C:\ScaleBridge\logs\`
2. Verify `.env` configuration
3. Test manual run: `node index.js`
4. Check backend status: https://api.grettas-erp.com/health

---

## Summary Checklist

After installation at each branch, verify:

- [ ] Node.js installed
- [ ] Files copied to `C:\ScaleBridge\`
- [ ] `npm install` completed
- [ ] `.env` file created with correct Branch ID
- [ ] Manual test successful (`node index.js`)
- [ ] Windows service installed
- [ ] Service status is "Running"
- [ ] Logs show successful connection
- [ ] Backend monitoring endpoint shows branch as connected
- [ ] Scale connection test works from frontend

---

## Next Steps After All Branches Connected

Once all 4 branches have Scale Bridge installed:

1. Test scale communication at each branch
2. Verify price uploads work
3. Train staff on scale features
4. Monitor logs for any issues
5. Set up automated monitoring/alerting

---

## Contact Information

For technical support with Scale Bridge installation:
- Check documentation in `/home/erp-pos-system/scale-bridge/`
- Review verification report: `VERIFICATION.md`
- Branch IDs reference: `BRANCH_IDS.txt`
