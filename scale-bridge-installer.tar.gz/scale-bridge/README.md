# Scale Bridge - Local Synchronization Service

## What is Scale Bridge?

Scale Bridge is a lightweight service that runs locally at each branch to enable communication between the cloud-based backend and the local Kretz Aura scale.

### The Problem It Solves

The backend server is hosted on a cloud VPS (138.219.41.188), but the Kretz Aura scales are on each branch's private local network (192.168.x.x). The cloud server **cannot reach private IP addresses**, making direct scale communication impossible.

### Architecture

```
┌─────────────────────────────────────────────────────────────┐
│ Cloud Backend (https://api.grettas-erp.com)                 │
│           ↕ WebSocket (HTTPS - secure outbound connection) │
└─────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────┐
│ Scale Bridge (runs at branch)                                │
│           ↕ FTP/HTTP/TCP (local network)                    │
└─────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────┐
│ Kretz Aura Scale (192.168.1.100)                            │
└─────────────────────────────────────────────────────────────┘
```

**Benefits:**
- ✅ No VPN required
- ✅ No port forwarding required
- ✅ No firewall configuration changes
- ✅ Secure HTTPS WebSocket connection
- ✅ Automatic reconnection on network issues
- ✅ Runs as Windows service (auto-starts on boot)

---

## Installation Instructions

### Prerequisites

- **Node.js 18.x or higher** installed on Windows PC at branch
- **Administrator privileges** to install Windows service
- **Branch ID** (get from system administrator)
- **Scale IP address** and credentials (if FTP)

### Step 1: Download Files

Copy the entire `scale-bridge` folder to the branch PC. Recommended location:
```
C:\gretta-erp\scale-bridge\
```

### Step 2: Install Dependencies

Open **Command Prompt as Administrator** and navigate to the folder:

```bash
cd C:\gretta-erp\scale-bridge
npm install
```

This will install all required Node.js packages.

### Step 3: Configure

1. Copy `.env.example` to `.env`:
   ```bash
   copy .env.example .env
   ```

2. Edit `.env` file with Notepad:
   ```bash
   notepad .env
   ```

3. Set your branch ID (REQUIRED):
   ```env
   BRANCH_ID=your-branch-uuid-here
   ```

   **Get your branch UUID from:**
   - System administrator
   - Or database: `SELECT id, name FROM branches;`
   - Or backend logs during login

4. Verify backend URL (default is production):
   ```env
   BACKEND_URL=https://api.grettas-erp.com
   ```

### Step 4: Test the Service

Before installing as a service, test it manually:

```bash
npm start
```

You should see:
```
=== Scale Bridge Service Starting ===
Branch ID: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
Backend URL: https://api.grettas-erp.com
Connecting to backend...
✅ Connected to backend successfully
```

Press `Ctrl+C` to stop.

### Step 5: Install as Windows Service

This allows the service to run automatically on system startup.

**Run as Administrator:**

```bash
npm run install-service
```

You should see:
```
✅ Scale Bridge service installed successfully!
✅ Service started!
```

**Verify the service is running:**

1. Open Windows Services (`services.msc`)
2. Find "Scale Bridge" in the list
3. Status should be "Running"
4. Startup Type should be "Automatic"

---

## Usage

### Testing Scale Connection

Once the bridge is running, use the ERP frontend:

1. Go to **Configuración** → **Balanza**
2. Enter scale IP address (e.g., `192.168.1.100`)
3. Enter scale port (default: `21` for FTP)
4. Select protocol (FTP, HTTP, or TCP)
5. Enter FTP credentials if using FTP
6. Click **Probar Conexión**

The frontend will send the test command to the backend, which forwards it to the Scale Bridge at your branch, which then connects to the local scale.

### Synchronizing Products

1. Configure scale settings (see above)
2. Enable **Sincronización Automática**
3. Choose frequency (Manual, Hourly, Daily)
4. Click **Sincronizar Ahora** to test

The price list will be generated on the backend and sent to the Scale Bridge, which uploads it to the scale via FTP.

---

## Troubleshooting

### Service won't start

**Check logs:**
```bash
cd C:\gretta-erp\scale-bridge\logs
notepad combined.log
```

**Common issues:**

1. **"BRANCH_ID not configured"**
   - Edit `.env` file and set `BRANCH_ID=your-uuid`

2. **"Connection error"**
   - Check internet connection
   - Verify `BACKEND_URL` in `.env`
   - Check if backend is online: https://api.grettas-erp.com/health

3. **"FTP connection failed"**
   - Verify scale IP address is correct
   - Verify scale is powered on and connected to network
   - Ping the scale: `ping 192.168.1.100`
   - Check FTP credentials
   - Try connecting with FTP client (FileZilla) to verify scale FTP works

### View Logs

Logs are stored in:
```
C:\gretta-erp\scale-bridge\logs\
```

Files:
- `combined.log` - All log messages
- `error.log` - Only errors

### Restart Service

**Via Services Manager:**
1. Open `services.msc`
2. Find "Scale Bridge"
3. Right-click → Restart

**Via Command Prompt (Administrator):**
```bash
net stop "Scale Bridge"
net start "Scale Bridge"
```

### Uninstall Service

```bash
cd C:\gretta-erp\scale-bridge
npm run uninstall-service
```

### Check Service Status

Open `services.msc` and find "Scale Bridge", or:

```bash
sc query "Scale Bridge"
```

---

## For Developers

### Architecture

**WebSocket Events:**

**From Bridge → Backend:**
- `bridge:register` - Bridge registers on connection
- `pong` - Keepalive response
- `scale:test-connection-result` - Test result
- `scale:sync-result` - Sync result

**From Backend → Bridge:**
- `ping` - Keepalive check
- `scale:test-connection` - Test scale connection
- `scale:sync` - Upload price list to scale

**Request/Response Pattern:**

Each request includes a `request_id` that the bridge includes in the response, allowing the backend to match requests with responses.

### Running in Development

```bash
npm start
```

### Environment Variables

- `BRANCH_ID` (required) - Branch UUID
- `BACKEND_URL` (default: https://api.grettas-erp.com) - Backend URL
- `LOG_LEVEL` (default: info) - Log level (debug, info, warn, error)

### Testing Without Backend

You can test the scale client directly:

```javascript
const ScaleClient = require('./scaleClient');

const client = new ScaleClient();

// Test connection
client.testConnection({
  ip: '192.168.1.100',
  port: 21,
  protocol: 'ftp',
  username: 'admin',
  password: 'password'
}).then(result => {
  console.log('Connection test result:', result);
}).catch(error => {
  console.error('Connection test failed:', error);
});
```

---

## Support

For issues or questions:
1. Check logs in `logs/` folder
2. Verify `.env` configuration
3. Test scale connection manually with FTP client
4. Contact system administrator

---

## Version History

### v1.0.0 (2026-01-29)
- Initial release
- FTP, HTTP, and TCP protocol support
- Windows service installation
- Automatic reconnection
- Logging system
